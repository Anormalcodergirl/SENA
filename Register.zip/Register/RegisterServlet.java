
package com.myservlets.servlets;

import com.java.models.User;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class RegisterServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
  
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        String username = request.getParameter("username");
        String useremail = request.getParameter("useremail");
        String userpass = request.getParameter("userpass");
        String userrepass = request.getParameter("userrepass");
        String usernumber = request.getParameter("number");
        // Perform validation
        boolean isValid = validateInput(username, useremail, userpass, userrepass, usernumber);

        User user = new User(username,useremail,usernumber);
        
        if (isValid && (userpass.equals(userrepass))) {
            
            if(isInDataBase(useremail)){
                
                request.setAttribute("userConnection", user);
                RequestDispatcher dispatcher = request.getRequestDispatcher("register.jsp?error=emailused");
                dispatcher.forward(request, response);
                
                return;
            }
            
            saveUser(username,userpass,useremail,usernumber);
            response.sendRedirect("login.jsp");
            
        } else {
            
            request.setAttribute("userConnection", user);
            RequestDispatcher dispatcher = request.getRequestDispatcher("register.jsp?error=invalid");
            dispatcher.forward(request, response);
        }
        
    }
    
    private boolean validateInput(String username, String useremail, String userpass, String userrepass, String number) {
        return !username.isEmpty() && !useremail.isEmpty() && !userpass.isEmpty() &&
                userpass.equals(userrepass) && !number.isEmpty();
    }

    public void saveUser(String name, String pass, String email, String number) {
        String filePath = User.URL; // Ruta del archivo de texto donde se guardarán los usuarios

        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(filePath, true));
            String userData = name + ";" + pass + ";" + email + ";" + number;
            writer.newLine();
            writer.write(new String(userData.getBytes(StandardCharsets.UTF_8), StandardCharsets.UTF_8));
            System.out.println("Usuario guardado correctamente.");
            
            writer.close();
            
        } catch (IOException e) {
            System.err.println("Error al guardar el usuario: " + e.getMessage());
        }
    }
    
    public boolean isInDataBase(String useremail){
        
        File file = new File(User.URL);
        String line;
        try {
            BufferedReader scanner;
             scanner = new BufferedReader(new FileReader(file));
            while ((line = scanner.readLine()) != null) {
                String[] userData = line.split(";");
                
                String storedEmail = userData[2];
                String storedPassword = userData[1];
                
                if (useremail.equals(storedEmail)) {
                    scanner.close();
                    return true;
                }
            }
            
            scanner.close();
        } catch (IOException ex) {
            Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
